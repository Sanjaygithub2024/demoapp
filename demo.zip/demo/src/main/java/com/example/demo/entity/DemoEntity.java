package com.example.demo.entity;

import org.hibernate.annotations.IdGeneratorType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;

@Entity("DemoTable")
public class DemoEntity {
	
	@IdGeneratorType
	@Column("demoId")
	private Integer demoId;

}
