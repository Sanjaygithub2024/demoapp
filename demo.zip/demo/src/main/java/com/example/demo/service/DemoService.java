package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.common.RequestDto;
import com.example.demo.common.ResponseDto;
import com.example.demo.dao.DemoRepostory;

import jakarta.transaction.Transactional;

@Service
public class DemoService {
	
	
	@Autowired
	DemoRepostory reposotry;
	
	@Transactional
	ResponseDto saveDemo(RequestDto request) {
		
		ResponseDto response = new ResponseDto();
		try {
			reposotry.save(request);
		} catch (Exception e) {
			response.setErrorCode(301);
			response.setErrorMessage(e.getMessage());
		}
		
		
		
	}

}
