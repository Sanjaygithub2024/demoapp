package com.example.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.DemoEntity;

public interface DemoRepostory extends JpaRepository<DemoEntity, Integer> {
	
	
}
